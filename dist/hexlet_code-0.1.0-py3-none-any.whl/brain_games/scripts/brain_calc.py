#!/usr/bin/env python3

from brain_games.games.calc import run_calc_game


def main():
    run_calc_game()


if __name__ == '__main__':
    main()
