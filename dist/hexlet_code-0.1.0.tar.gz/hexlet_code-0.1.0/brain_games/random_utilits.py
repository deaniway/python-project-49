import random


def generate_random_number():
    return random.randint(0, 9)


def generate_number():
    return random.randrange(50)
