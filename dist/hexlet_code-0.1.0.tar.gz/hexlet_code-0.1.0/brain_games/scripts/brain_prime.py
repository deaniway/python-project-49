#!/usr/bin/env python3

from brain_games.engine import engie
from brain_games.games import prime


def main():
    engie(prime)


if __name__ == '__main__':
    main()
